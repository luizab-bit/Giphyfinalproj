import React from "react";
import Giphy from "./components/Giphy";
import "./App.css";
import Header from "./components/Header";


const App = () =>{
    return <div><Header/><Giphy/></div>
}

export default App;